function calculateDays() {
    const input = document.getElementById("birthdate").value;
    const resultDiv = document.getElementById("result");
    const loader = document.getElementById("loader");

    // Проверка формата
    const regex = /^(\d{2})\.(\d{2})\.(\d{4})$/;
    const match = input.match(regex);

    if (!match) {
        resultDiv.textContent = "Введите дату в формате ДД.ММ.ГГГГ";
        return;
    }

    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10) - 1;
    const year = parseInt(match[3], 10);

    const birth = new Date(year, month, day);
    if (isNaN(birth)) {
        resultDiv.textContent = "Неверная дата!";
        return;
    }

    // Показываем загрузку
    loader.style.display = "block";
    resultDiv.textContent = "";

    setTimeout(() => {
        const today = new Date();
        const diffTime = today - birth;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        loader.style.display = "none";
        resultDiv.textContent = `Вы прожили ${diffDays} дней!`;
    }, 2000);
}